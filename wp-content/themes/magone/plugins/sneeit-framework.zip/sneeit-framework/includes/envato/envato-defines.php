<?php
define('SNEEIT_ENVATO_OPT_USER_NAME', 'sneeit-envato-opt-user-name');
define('SNEEIT_ENVATO_OPT_API_KEY', 'sneeit-envato-opt-key');
define('SNEEIT_ENVATO_THEME_ACTIVATION', 'sneeit-envato-theme-activation');
define('SNEEIT_ENVATO_TRANSIENT_UPDATE_RESULT', 'sneeit-envato-transient-update-result');
define('SNEEIT_ENVATO_THEME_AUTO_UPDATE', 'sneeit-envato-theme-auto-update');
define('SNEEIT_ENVATO_THEME_AUTO_UPDATE_TMP_FOLDER', WP_CONTENT_DIR.'/sneeit-envato-theme-auto-update');