<?php
if (is_admin()) :
	include_once 'envato-defines.php';
	include_once 'envato-theme-activation.php';
	include_once 'envato-theme-auto-update.php';
endif;