<?php
define('SNEEIT_SNEEIT_OPT_USER_NAME', 'sneeit-sneeit-opt-user-name');
define('SNEEIT_SNEEIT_OPT_LICENSE_KEY', 'sneeit-sneeit-opt-key');
define('SNEEIT_SNEEIT_THEME_ACTIVATION', 'sneeit-sneeit-theme-activation');
define('SNEEIT_SNEEIT_TRANSIENT_UPDATE_RESULT', 'sneeit-sneeit-transient-update-result');
define('SNEEIT_SNEEIT_THEME_AUTO_UPDATE', 'sneeit-sneeit-theme-auto-update');
define('SNEEIT_SNEEIT_THEME_AUTO_UPDATE_TMP_FOLDER', WP_CONTENT_DIR.'/sneeit-sneeit-theme-auto-update');